# Roll-a-ball-game-in-Unity

Here in this game the ball well move in all this cubes to score and win the game
![Screen Shot 2019-08-05 at 9 53 36 PM](https://user-images.githubusercontent.com/52737328/62489679-6792be80-b7d8-11e9-80e6-1b43bf2d62e5.png)
